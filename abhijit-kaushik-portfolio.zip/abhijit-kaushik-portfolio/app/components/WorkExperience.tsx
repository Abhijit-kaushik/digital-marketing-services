import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

const experiences = [
  {
    title: "Digital Marketing Manager",
    company: "Alphawizz Technologies Pvt. Ltd.",
    period: "July 2024 - Present",
    responsibilities: [
      "Directed and managed digital marketing initiatives, significantly enhancing brand awareness and customer engagement.",
      "Developed and executed comprehensive strategies, resulting in a 30% boost in search ranking & visibility.",
      "Utilized various digital marketing channels to reach target audiences effectively.",
      "Analyzed and optimized campaigns based on data-driven insights, improving conversion rates and ROI.",
      "Led a team of digital marketing professionals, offering guidance and support to achieve team goals."
    ]
  },
  {
    title: "Digital Marketing Manager",
    company: "NailKnack - Press on Nails",
    period: "April 2023 - June 2024",
    responsibilities: [
      "Managed e-commerce operations across Amazon and Flipkart, ensuring efficient business processes.",
      "Developed and executed SEO strategies, resulting in improved search rankings and visibility.",
      "Designed and created graphic elements for Amazon store, product images, website visuals, and ads.",
      "Optimized Google Ad campaigns with persuasive content and targeted keywords, driving brand awareness and sales.",
      "Developed and maintained landing pages to enhance visibility and conversions."
    ]
  },
  {
    title: "Digital Marketing Lead",
    company: "Reinforce Software Solutions Pvt. Ltd.",
    period: "Sept 2021 - Sept 2022",
    responsibilities: [
      "Led a team of designers, SEO experts, and analysts, ensuring successful project delivery.",
      "Created engaging content for LinkedIn and Facebook, enhancing brand visibility and engagement.",
      "Launched and optimized PPC campaigns, achieving a 50% increase in visitors through Google Display and Search Ads.",
      "Managed budgets and bids to maximize ROI and efficient resource allocation.",
      "Developed and executed SEO strategies to drive organic traffic and improve rankings."
    ]
  },
  {
    title: "Digital Marketing Specialist",
    company: "TECH DRIVEN BASIC (TDB.AI)",
    period: "Aug 2020 - Sept 2021",
    responsibilities: [
      "Led a team in executing digital marketing strategies, achieving significant business growth and brand visibility.",
      "Implemented an SEO-driven organic strategy, resulting in a 600% increase in site visits and high conversion rates.",
      "Built a strong social media presence on multiple platforms, increasing brand awareness and engagement.",
      "Created and promoted video content, leading to a 223% increase in engagement and 122% in conversions.",
      "Produced high-quality video content, including social stories, marketing videos, and e-learning materials.",
      "Executed online marketing strategies to drive traffic, sales, and conversions."
    ]
  },
  {
    title: "Digital Marketing Executive",
    company: "DB CORP LTD (DAINIK BHASKAR)",
    period: "Jan 2019 - June 2020",
    responsibilities: [
      "Implemented SEO-driven strategies, leading to a 150% increase in site visits and a 5% increase in sales.",
      "Executed SMO-driven strategies, achieving a 200% increase in site visits within 6 months.",
      "Led successful campaigns and created engaging content to build a social media audience.",
      "Conducted data analysis and research to understand city behavior and demographics.",
      "Maintained accuracy in reporting and documentation, ensuring effective communication."
    ]
  },
  {
    title: "Audit & Guests Relations Officer",
    company: "BARBEQUE-NATION HOSPITALITY LTD. (SAYAJI HOTELS LTD.)",
    period: "Dec 2015 - Oct 2018",
    responsibilities: [
      "Managed guest feedback and experiences, ensuring high levels of satisfaction and prompt issue resolution.",
      "Oversaw property operations, focusing on guest satisfaction, employee support, sales, marketing, audit accounting, and financial control.",
      "Prepared and submitted detailed reports and conducted staff training, ensuring adherence to company standards.",
      "Coordinated daily hotel operations, maintaining a 100% guest satisfaction rate."
    ]
  },
  {
    title: "Faculty",
    company: "RAJEEV GANDHI COMPUTER SAKSHARTA MISSION",
    period: "Jan 2005 - Jun 2010",
    responsibilities: [
      "Served as a faculty member for the Advance Diploma in Computer Application and Programming, Internet, MS Office, DTP, Tally, AutoCAD, etc., delivering high-quality instruction and guidance to students.",
      "Developed and implemented curriculum and lesson plans, ensuring the effective delivery of course material and the achievement of learning objectives.",
      "Prepared and presented monthly account reports to management, providing accurate and timely financial information for decision-making purposes.",
      "Managed internal and external mail functions, ensuring the efficient and timely distribution of correspondence.",
      "Maintained clear and concise documentation, facilitating ease of understanding and seamless knowledge transfer between faculty and students.",
      "Utilized effective teaching techniques and strategies to engage students and promote active learning.",
      "Consistently received positive feedback from students and colleagues for ability to explain complex concepts in a clear and understandable manner.",
      "Diligently proofread all reports and communications, ensuring they were error-free and conveyed the intended message accurately."
    ]
  }
]

export default function WorkExperience() {
  return (
    <section className="py-20 px-6">
      <div className="container mx-auto">
        <h2 className="text-3xl font-bold text-center mb-12 bg-clip-text text-transparent bg-gradient-to-r from-white to-primary">Work Experience</h2>
        <div className="space-y-8">
          {experiences.map((exp, index) => (
            <Card key={index}>
              <CardHeader>
                <CardTitle>{exp.title}</CardTitle>
                <p className="text-sm text-muted-foreground">{exp.company} | {exp.period}</p>
              </CardHeader>
              <CardContent>
                <ul className="list-disc pl-5 space-y-2">
                  {exp.responsibilities.map((resp, respIndex) => (
                    <li key={respIndex}>{resp}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

