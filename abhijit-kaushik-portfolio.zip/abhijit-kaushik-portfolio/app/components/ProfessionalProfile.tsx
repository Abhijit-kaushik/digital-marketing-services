import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function ProfessionalProfile() {
  return (
    <section className="py-20 px-6">
      <div className="container mx-auto">
        <h2 className="text-3xl font-bold text-center mb-12">Professional Profile</h2>
        <Card>
          <CardHeader>
            <CardTitle>Abhijit Kaushik - Digital Marketing Manager</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-4">
              Results-oriented Digital Marketing Manager with extensive experience in e-commerce, SEO,
              and graphic design. Demonstrated success in managing digital marketing campaigns across
              platforms like Amazon and Flipkart, leading to increased brand visibility and sales.
            </p>
            <p className="mb-4">
              Proficient in Google Ads management, Google Analytics, Google Tag Manager, Google Search Console,
              and Google Merchant Center, as well as SEO-driven organic growth and social media engagement.
            </p>
            <p>
              Known for leading cross-functional teams and aligning marketing strategies with business goals
              while staying abreast of industry trends to implement innovative solutions.
            </p>
          </CardContent>
        </Card>
      </div>
    </section>
  )
}

