import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card"
import { Megaphone, BarChart, Search, Mail, Target, DollarSign } from 'lucide-react'

const services = [
  {
    title: "SEO Optimization",
    description: "Improve your search rankings and drive organic traffic to your website.",
    icon: Search,
    details: "Our comprehensive SEO packages help boost your visibility in search engine results."
  },
  {
    title: "Content Marketing",
    description: "Create compelling content that resonates with your target audience.",
    icon: BarChart,
    details: "We develop and execute content strategies that engage your audience and establish thought leadership."
  },
  {
    title: "Social Media Management",
    description: "Engage your audience and build brand loyalty across all major platforms.",
    icon: Megaphone,
    details: "Our cost-effective social media management services help you connect with your audience and grow your brand presence."
  },
  {
    title: "Email Marketing",
    description: "Nurture leads and drive conversions with targeted email campaigns.",
    icon: Mail,
    details: "We create customized email marketing campaigns that deliver personalized messages to your subscribers."
  },
  {
    title: "PPC Advertising",
    description: "Drive targeted traffic and increase conversions with pay-per-click advertising.",
    icon: Target,
    details: "Our team specializes in creating and managing high-performing PPC campaigns across various platforms."
  },
  {
    title: "B2B Marketing",
    description: "Develop strategies tailored for business-to-business growth and lead generation.",
    icon: DollarSign,
    details: "We offer specialized B2B marketing services, including Account-Based Marketing (ABM) and LinkedIn strategies."
  }
]

export default function Services() {
  return (
    <section id="services" className="py-20 px-6 bg-background">
      <div className="container mx-auto">
        <h2 className="text-3xl font-bold text-center mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-primary">My Services</h2>
        <p className="text-center mb-12 max-w-3xl mx-auto text-muted-foreground">
          I offer a wide range of digital marketing services to help businesses promote themselves online. By utilizing these services, I help businesses reach specific audiences, build engagement, and drive conversions.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Card key={index} className="bg-card hover:bg-accent transition-colors">
              <CardHeader>
                <service.icon className="w-12 h-12 mb-4 text-primary" />
                <CardTitle className="text-foreground">{service.title}</CardTitle>
                <CardDescription className="text-muted-foreground">{service.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{service.details}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

