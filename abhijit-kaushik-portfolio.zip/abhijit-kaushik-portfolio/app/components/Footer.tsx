import { Linkedin } from 'lucide-react'
import Link from 'next/link'

export default function Footer() {
  return (
    <footer className="py-12 px-6 bg-secondary text-secondary-foreground">
      <div className="container mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
        <div>
          <h3 className="text-lg font-semibold mb-4">About Abhijit Kaushik</h3>
          <p className="text-sm">
            Abhijit Kaushik is a digital marketing expert specializing in comprehensive strategies to help businesses grow in the digital landscape.
          </p>
        </div>
        <div>
          <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
          <ul className="space-y-2 text-sm">
            <li><Link href="#services">My Services</Link></li>
            <li><Link href="#case-studies">Case Studies</Link></li>
            <li><Link href="#testimonials">Testimonials</Link></li>
            <li><Link href="#contact">Contact</Link></li>
          </ul>
        </div>
        <div>
          <h3 className="text-lg font-semibold mb-4">Connect With Me</h3>
          <div className="flex space-x-4">
            <a href="https://www.linkedin.com/in/abhijitdigitalmarketingexpert-seoexpert-socialmediamanagement-googleadsexpert/" target="_blank" rel="noopener noreferrer" className="hover:text-primary">
              <Linkedin size={24} />
            </a>
          </div>
        </div>
      </div>
      <div className="container mx-auto mt-8 pt-8 border-t border-secondary-foreground/10 text-center text-sm">
        <p>&copy; {new Date().getFullYear()} Abhijit Kaushik. All rights reserved.</p>
      </div>
    </footer>
  )
}

