import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Eye, BarChart2, Users, TrendingUp } from 'lucide-react'

const benefits = [
  {
    title: "Enhanced Brand Visibility",
    description: "Increase your online presence and reach a wider audience.",
    icon: Eye
  },
  {
    title: "Targeted Traffic",
    description: "Drive qualified visitors to your website who are more likely to convert.",
    icon: BarChart2
  },
  {
    title: "Improved Customer Engagement",
    description: "Connect with your audience through personalized campaigns.",
    icon: Users
  },
  {
    title: "Measurable Results",
    description: "Track your ROI and optimize your marketing efforts based on data.",
    icon: TrendingUp
  }
]

export default function Benefits() {
  return (
    <section className="py-20 px-6 bg-secondary/10">
      <h2 className="text-3xl font-bold text-center mb-6">Benefits of Digital Marketing</h2>
      <p className="text-center mb-12 max-w-3xl mx-auto text-muted-foreground">
        Discover how digital marketing can transform your business and drive growth in the digital age.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {benefits.map((benefit, index) => (
          <Card key={index}>
            <CardHeader>
              <benefit.icon className="w-12 h-12 mb-4 text-primary" />
              <CardTitle>{benefit.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">{benefit.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  )
}

