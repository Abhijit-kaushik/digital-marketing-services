import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const skills = [
  "Amazon Seller Profile Management",
  "On-Page SEO",
  "Off-Page SEO",
  "Google Ads Management",
  "Google Analytics",
  "Google Tag Manager",
  "Google Search Console",
  "Google Merchant Center",
  "Amazon Ads",
  "Amazon Cataloging",
  "Amazon Store Development",
  "Meta Ads",
  "LinkedIn Ads & Marketing",
  "Content Creation",
  "Graphics Designing",
  "Video Editing",
  "AI Technologies"
]

const tools = [
  "Google Keyword Planner",
  "SEMrush",
  "Ubersuggest",
  "Keywordtool.io",
  "ChatGPT",
  "Canva",
  "Grammarly",
  "Invideo",
  "Helium 10",
  "QuillBot",
  "Writesonic",
  "SEO Site Checkup",
  "SEOptimer",
  "StableDiffusion",
  "Midjourney",
  "Google colab",
  "Wordtune",
  "TubeRanker",
  "Freepik",
  "Envato Elements",
  "Adobe Photoshop",
  "Adobe Premiere Pro"
]

export default function SkillsExpertise() {
  return (
    <section className="py-20 px-6 bg-secondary/10">
      <div className="container mx-auto">
        <h2 className="text-3xl font-bold text-center mb-12">Skills & Expertise</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle>Technical Skills</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {skills.map((skill, index) => (
                  <Badge key={index} variant="secondary">{skill}</Badge>
                ))}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Tools & Technologies</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {tools.map((tool, index) => (
                  <Badge key={index} variant="outline">{tool}</Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}

