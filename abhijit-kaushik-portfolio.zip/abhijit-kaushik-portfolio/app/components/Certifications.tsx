import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

const certifications = [
  {
    title: "LinkedIn Content and Creative Design",
    issuer: "LinkedIn Marketing Labs",
    period: "Sept 2024 - Sept 2026"
  },
  {
    title: "LinkedIn Marketing Strategy",
    issuer: "LinkedIn Marketing Labs",
    period: "Sept 2024 - Sept 2026"
  },
  {
    title: "LinkedIn Marketing Fundamentals",
    issuer: "LinkedIn Marketing Labs",
    period: "Sept 2024 - Sept 2026"
  },
  {
    title: "The Ultimate SEO Training 2022 + SEO For Wordpress Websites",
    issuer: "ClickSlice SEO Agency, UK",
    period: "Oct 2021 - No Expiration"
  },
  {
    title: "Facebook Ads & Facebook Marketing MASTERY 2022",
    issuer: "Coursenvy Envy ad agency, LA, USA",
    period: "Nov 2021 - No Expiration"
  },
  {
    title: "Ultimate Google Ads Training 2021",
    issuer: "AdVenture Media, Long Island, NY, USA",
    period: "Dec 2021 - No Expiration"
  },
  {
    title: "Flipkart Advertising Certification",
    issuer: "Flipkart.com",
    period: "Jan 2021 - No Expiration"
  },
  {
    title: "Digital Marketing Certification",
    issuer: "IIM - Indore",
    period: "Sept 2018 - No Expiration"
  }
]

export default function Certifications() {
  return (
    <section className="py-20 px-6 bg-secondary/10">
      <div className="container mx-auto">
        <h2 className="text-3xl font-bold text-center mb-12 bg-clip-text text-transparent bg-gradient-to-r from-white to-primary">Certifications</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {certifications.map((cert, index) => (
            <Card key={index}>
              <CardHeader>
                <CardTitle className="text-lg">{cert.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{cert.issuer}</p>
                <p className="text-sm">{cert.period}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

