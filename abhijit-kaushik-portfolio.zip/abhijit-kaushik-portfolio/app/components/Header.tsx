import Link from 'next/link'
import { Button } from "@/components/ui/button"

export default function Header() {
  return (
    <header className="py-4 px-6 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50 w-full border-b border-border/40">
      <div className="container mx-auto flex justify-between items-center">
        <Link href="/" className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-primary">Abhijit Kaushik</Link>
        <nav className="space-x-4 flex items-center">
          <Link href="#services" className="text-muted-foreground hover:text-primary transition-colors">Services</Link>
          <Link href="#case-studies" className="text-muted-foreground hover:text-primary transition-colors">Case Studies</Link>
          <Link href="#testimonials" className="text-muted-foreground hover:text-primary transition-colors">Testimonials</Link>
          <Button asChild>
            <Link href="#contact">Contact</Link>
          </Button>
        </nav>
      </div>
    </header>
  )
}

