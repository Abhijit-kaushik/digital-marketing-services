import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export default function Testimonials() {
  return (
    <section id="testimonials" className="py-20 px-6">
      <div className="container mx-auto">
        <h2 className="text-3xl font-bold text-center mb-12 bg-clip-text text-transparent bg-gradient-to-r from-white to-primary">Client Testimonial</h2>
        <div className="max-w-4xl mx-auto">
          <Card className="bg-card">
            <CardHeader>
              <div className="flex items-center space-x-4">
                <Avatar className="w-20 h-20">
                  <AvatarImage src="/Screenshot_20241219-160619-257.png" alt="Ms. Vidushi Keshri" />
                  <AvatarFallback>VK</AvatarFallback>
                </Avatar>
                <div>
                  <CardTitle className="text-xl">Ms. Vidushi Keshri</CardTitle>
                  <p className="text-primary font-medium">CEO, NailKnack®</p>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground italic">
                "Working with Abhijit Kaushik has been a game-changer for NailKnack. Their expertise in SEO, digital content, and Amazon Storefront optimization has played a pivotal role in elevating our brand's digital presence and driving impressive sales growth. Through a well-executed SEO strategy, we saw a significant improvement in our search rankings, which resulted in more traffic and conversions. Additionally, the optimized Google Ads campaigns helped us reach a wider audience and generate high-quality leads, further boosting our visibility."
              </p>
              <p className="text-muted-foreground italic">
                "The team also took our Amazon storefront to the next level, improving both its functionality and SEO, which directly contributed to an 220% increase in sales. The optimization of our product listings and A+ content was instrumental in helping NailKnack rank among the top 100 products in our category on Amazon India."
              </p>
              <p className="text-muted-foreground italic">
                "Thanks to Abhijit and their team, we've experienced remarkable growth, and we are excited about the future. I highly recommend their services to anyone looking to enhance their digital marketing strategy and achieve outstanding results."
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}

