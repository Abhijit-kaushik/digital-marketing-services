import { Button } from "@/components/ui/button"

export default function Hero() {
  return (
    <section className="py-20 px-6 text-center bg-gradient-to-b from-background to-secondary">
      <div className="container mx-auto">
        <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-primary">Comprehensive Digital Marketing Services</h1>
        <p className="text-xl mb-8 max-w-3xl mx-auto text-muted-foreground">
          Abhijit Kaushik provides far-reaching digital marketing services to help businesses of all sizes achieve their goals. Using cutting-edge strategies and tools in a measured manner, we team up to deliver reliable ways for companies to grow in today's competitive landscape.
        </p>
        <Button size="lg" asChild className="bg-primary hover:bg-primary/90 text-primary-foreground">
          <a href="#contact">Get Started</a>
        </Button>
      </div>
    </section>
  )
}

