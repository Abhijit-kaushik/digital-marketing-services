import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Check } from 'lucide-react'

const packages = [
  {
    title: "Basic",
    features: [
      "Comprehensive SEO audit",
      "On-page optimization",
      "Monthly performance reports",
      "Basic social media management"
    ],
    price: "$499/month"
  },
  {
    title: "Standard",
    features: [
      "All Basic features",
      "Content marketing strategy",
      "PPC campaign management",
      "Email marketing campaigns"
    ],
    price: "$999/month"
  },
  {
    title: "Premium",
    features: [
      "All Standard features",
      "Advanced SEO techniques",
      "Social media advertising",
      "Conversion rate optimization"
    ],
    price: "$1,999/month"
  }
]

export default function Packages() {
  return (
    <section className="py-20 px-6">
      <h2 className="text-3xl font-bold text-center mb-6">Digital Marketing Packages</h2>
      <p className="text-center mb-12 max-w-3xl mx-auto text-muted-foreground">
        Choose from our customizable packages to suit your business needs and budget.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {packages.map((pkg, index) => (
          <Card key={index} className="flex flex-col">
            <CardHeader>
              <CardTitle className="text-2xl text-center">{pkg.title}</CardTitle>
            </CardHeader>
            <CardContent className="flex-grow">
              <ul className="space-y-2">
                {pkg.features.map((feature, fIndex) => (
                  <li key={fIndex} className="flex items-center">
                    <Check className="w-5 h-5 mr-2 text-primary" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter className="flex flex-col items-center">
              <p className="text-2xl font-bold mb-4">{pkg.price}</p>
              <Button>Get Started</Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </section>
  )
}

