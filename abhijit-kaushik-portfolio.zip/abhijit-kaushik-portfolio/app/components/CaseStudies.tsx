import Image from 'next/image'
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

const caseStudies = [
  {
    title: "Comprehensive Digital Marketing for NailKnack®",
    description: "A complete digital transformation across multiple platforms including Amazon, Google Ads, SEO, and Digital Content Optimization.",
    image: "/placeholder.svg?height=200&width=300",
    details: [
      {
        subtitle: "Overall Campaign Success",
        points: [
          "Total Sales: ₹4,30,162.25",
          "Total Order Items: 716",
          "Average Sales/Order Item: ₹600.79",
          "Average Units/Order Item: 1.01"
        ]
      },
      {
        subtitle: "Google Ads Performance",
        points: [
          "Display Campaign: 74,019 clicks, 6.68% CTR, 36.82% conversion rate",
          "Search Campaigns: Combined 4,884 clicks with over 2,449 conversions",
          "Cost-effective campaigns with excellent ROI"
        ]
      },
      {
        subtitle: "SEO & Content Achievements",
        points: [
          "Ranked 7th for 'press-on nails' within 6 months",
          "80% increase in Amazon storefront sales",
          "Top 100 ranking in Amazon India's Artificial Nails category"
        ]
      }
    ],
    links: [
      {
        text: "Visit Website",
        url: "https://nailknack.com/"
      },
      {
        text: "Amazon Store",
        url: "https://www.amazon.in/stores/page/2DE03838-3168-4154-85FE-C04DE96156DD"
      }
    ]
  },
  {
    title: "E-commerce Revenue Optimization",
    description: "Strategic optimization of NailKnack's Amazon presence through comprehensive storefront development, product listing optimization, and SEO implementation.",
    image: "/placeholder.svg?height=200&width=300",
    details: [
      {
        subtitle: "Key Achievements",
        points: [
          "Optimized 350+ product listings",
          "Created SEO-optimized A+ content",
          "Implemented conversion-focused product descriptions",
          "220% increase in overall sales"
        ]
      }
    ],
    links: [
      {
        text: "View Products",
        url: "https://www.amazon.in/dp/B0CHP3NH5S/ref=tsm_1_fb_lk"
      }
    ]
  }
]

export default function CaseStudies() {
  return (
    <section id="case-studies" className="py-20 px-6 bg-secondary/10">
      <div className="container mx-auto">
        <h2 className="text-3xl font-bold text-center mb-12 bg-clip-text text-transparent bg-gradient-to-r from-white to-primary">Case Studies</h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {caseStudies.map((study, index) => (
            <Card key={index} className="flex flex-col">
              <Image 
                src={study.image} 
                alt={study.title} 
                width={600} 
                height={300} 
                className="w-full h-48 object-cover rounded-t-lg"
              />
              <CardHeader>
                <CardTitle className="text-xl font-bold">{study.title}</CardTitle>
                <p className="text-muted-foreground mt-2">{study.description}</p>
              </CardHeader>
              <CardContent className="flex-grow">
                {study.details.map((section, sectionIndex) => (
                  <div key={sectionIndex} className="mb-4">
                    <h3 className="font-semibold text-lg mb-2">{section.subtitle}</h3>
                    <ul className="list-disc pl-5 space-y-1">
                      {section.points.map((point, pointIndex) => (
                        <li key={pointIndex} className="text-muted-foreground">{point}</li>
                      ))}
                    </ul>
                  </div>
                ))}
                <div className="flex flex-wrap gap-4 mt-4">
                  {study.links.map((link, linkIndex) => (
                    <Button 
                      key={linkIndex}
                      variant="outline"
                      asChild
                    >
                      <a 
                        href={link.url}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        {link.text}
                      </a>
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

