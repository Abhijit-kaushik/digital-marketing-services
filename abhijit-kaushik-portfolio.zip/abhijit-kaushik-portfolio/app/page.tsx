import Header from './components/Header'
import Hero from './components/Hero'
import ProfessionalProfile from './components/ProfessionalProfile'
import Services from './components/Services'
import SkillsExpertise from './components/SkillsExpertise'
import WorkExperience from './components/WorkExperience'
import CaseStudies from './components/CaseStudies'
import Certifications from './components/Certifications'
import Testimonials from './components/Testimonials'
import ContactForm from './components/ContactForm'
import Footer from './components/Footer'

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <Hero />
        <ProfessionalProfile />
        <Services />
        <SkillsExpertise />
        <WorkExperience />
        <CaseStudies />
        <Certifications />
        <Testimonials />
        <ContactForm />
      </main>
      <Footer />
    </div>
  )
}

